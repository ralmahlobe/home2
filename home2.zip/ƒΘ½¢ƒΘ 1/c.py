import socket

def start_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(('127.0.0.1', 9999))

    while True:
        # استقبال البيانات من الخادم
        data = client.recv(1024).decode()
        print(data, end='')

        # إنهاء الاتصال إذا استلمنا الرصيد النهائي
        if 'Your final balance is' in data:
            break

        # إدخال المستخدم وإرساله للخادم
        user_input = input()
        client.send(user_input.encode())

    client.close()

if __name__ == "__main__":
    start_client()
